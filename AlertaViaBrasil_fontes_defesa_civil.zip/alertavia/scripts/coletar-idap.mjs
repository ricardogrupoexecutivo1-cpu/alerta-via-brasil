// Agregador gratuito de alertas públicos: IDAP/CAP + CEMADEN + Defesa Civil SC.
// O IDAP é a fonte nacional principal. As demais fontes complementam onde publicam dados abertos.
import { writeFileSync, mkdirSync } from 'node:fs';

const FEED = process.env.IDAP_URL || 'https://idapfile.mdr.gov.br/idap/api/rss/cap';
const SOURCES = [
  { id: 'idap', nome: 'Defesa Civil Nacional / IDAP', url: FEED, tipo: 'CAP 1.2', cobertura: 'Nacional; alertas estaduais/municipais publicados no IDAP' },
  { id: 'cemaden', nome: 'CEMADEN', url: 'https://painelalertas.cemaden.gov.br/wsAlertas2', tipo: 'JSON público não documentado', cobertura: 'Municípios monitorados pelo CEMADEN' },
  { id: 'defesa-sc', nome: 'Defesa Civil de Santa Catarina', url: 'https://defesacivil.sc.gov.br/categoria/alerta/feed/', tipo: 'RSS oficial', cobertura: 'Santa Catarina' },
  { id: 'epagri-sc', nome: 'EPAGRI/CIRAM', url: 'https://ciram.epagri.sc.gov.br/index.php/category/avisos-meteorologicos/feed/', tipo: 'RSS oficial', cobertura: 'Santa Catarina; avisos meteorológicos' }
];
const T = (n) => `(?:[\\w-]+:)?${n}`;
const dec = (s) => String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;|&#39;/g, "'").replace(/&amp;/g, '&').replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n)).replace(/&#x([\da-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n,16))).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
const one = (x, n) => { const m = x.match(new RegExp(`<${T(n)}(?:\\s[^>]*)?>([\\s\\S]*?)</${T(n)}>`)); return m ? dec(m[1]) : ''; };
const all = (x, n) => [...x.matchAll(new RegExp(`<${T(n)}(?:\\s[^>]*)?>([\\s\\S]*?)</${T(n)}>`, 'g'))].map((m) => m[1]);
const SEV = { minor: 1, moderate: 1, severe: 2, extreme: 3 };
const UFS = ['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'];
const IBGE_UF = { 11:'RO',12:'AC',13:'AM',14:'RR',15:'PA',16:'AP',17:'TO',21:'MA',22:'PI',23:'CE',24:'RN',25:'PB',26:'PE',27:'AL',28:'SE',29:'BA',31:'MG',32:'ES',33:'RJ',35:'SP',41:'PR',42:'SC',43:'RS',50:'MS',51:'MT',52:'GO',53:'DF' };
function ring(txt) { const pts = txt.trim().split(/\s+/).map((p) => p.split(',').map(Number)).filter((p) => p.length === 2 && p.every(Number.isFinite)); if (pts.length < 3) return null; const step = Math.max(1, Math.ceil(pts.length / 120)); const out=[]; let last=''; pts.forEach((p,i)=>{ if(i%step && i!==pts.length-1)return; const q=[+p[0].toFixed(3),+p[1].toFixed(3)],k=q.join(); if(k!==last)out.push(q);last=k;}); return out.length>=3?out:null; }
export function parseCap(xml, now = Date.now()) {
  const blocks = xml.match(new RegExp(`<${T('alert')}(?:\\s[^>]*)?>[\\s\\S]*?</${T('alert')}>`, 'g')) || []; const cancelled=new Set(), items=[];
  for (const b of blocks) { const id=one(b,'identifier'), type=one(b,'msgType').toLowerCase(), status=one(b,'status').toLowerCase(); if(status&&status!=='actual')continue; const refs=one(b,'references'); if(type==='cancel'){refs.split(/\s+/).forEach(r=>{const p=r.split(',');cancelled.add(p[1]||p[0]);});continue;} if(type==='update'&&refs)refs.split(/\s+/).forEach(r=>{const p=r.split(',');cancelled.add(p[1]||p[0]);});
    const infoBlocks=b.match(new RegExp(`<${T('info')}(?:\\s[^>]*)?>[\\s\\S]*?</${T('info')}>`,'g'))||[]; const pick=infoBlocks.find(i=>/pt/i.test(one(i,'language')))||infoBlocks[0]; if(!pick)continue; const exp=one(pick,'expires'), expT=exp?Date.parse(exp):NaN; if(Number.isFinite(expT)&&expT<now)continue;
    const areas=pick.match(new RegExp(`<${T('area')}(?:\\s[^>]*)?>[\\s\\S]*?</${T('area')}>`,'g'))||[],polys=[],geos=new Set(),desc=[]; for(const a of areas){desc.push(one(a,'areaDesc'));all(a,'polygon').forEach(p=>{const r=ring(dec(p));if(r)polys.push(r);});all(a,'geocode').forEach(g=>(dec(g).match(/\d{7}/g)||[]).forEach(c=>geos.add(c)));}
    const ufs=new Set(); geos.forEach(c=>IBGE_UF[c.slice(0,2)]&&ufs.add(IBGE_UF[c.slice(0,2)])); const text=desc.join(' '); UFS.forEach(u=>{if(new RegExp(`(?:^|[^A-Za-z])${u}(?:[^A-Za-z]|$)`).test(text))ufs.add(u);});
    items.push({id:String(id||`idap-${items.length}`),fonte:'Defesa Civil Nacional / IDAP',sender:one(b,'senderName')||one(b,'sender'),evento:one(pick,'event'),sev:SEV[one(pick,'severity').toLowerCase()]||1,urgencia:one(pick,'urgency'),certeza:one(pick,'certainty'),inicio:one(pick,'onset')||one(pick,'effective')||one(b,'sent'),fim:exp,titulo:one(pick,'headline'),descricao:one(pick,'description').slice(0,800),instrucao:one(pick,'instruction').slice(0,800),area:text.slice(0,400),ufs:[...ufs],ibge:[...geos].slice(0,400),poligonos:polys.slice(0,40),_t:Date.parse(one(b,'sent'))||0});
  }
  return items.filter(i=>!cancelled.has(i.id)).sort((a,b)=>b._t-a._t).map(({_t,...r})=>r);
}
const norm = s => String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
const severity = s => /extrem|muito alto|grande perigo|vermelh/i.test(s)?3:/alto|severo|laranja|alerta/i.test(s)?2:1;
async function fetchText(url, ms=25000) { const ctl=new AbortController(), timer=setTimeout(()=>ctl.abort(),ms); try { const r=await fetch(url,{headers:{'User-Agent':'AlertaViaBrasil/1.1 (agregador de alertas públicos)','Accept':'application/json, application/atom+xml, application/rss+xml, application/xml, text/xml, */*'},signal:ctl.signal}); if(!r.ok)throw new Error(`HTTP ${r.status}`); return await r.text(); } finally { clearTimeout(timer); } }
async function cemaden() {
  const raw=await fetchText('https://painelalertas.cemaden.gov.br/wsAlertas2'); const j=JSON.parse(raw); const arr=Array.isArray(j)?j:(j.alertas||j.data||j.resultados||[]);
  return arr.filter(a=>String(a.status??1)==='1'||a.ativo===true).map((a,i)=>{ const uf=String(a.uf||a.estado||'').toUpperCase().slice(0,2); const municipio=a.municipio||a.cidade||''; const nivel=String(a.nivel||a.severidade||''); return {id:`cemaden-${a.cod_alerta||a.id||i}`,fonte:'CEMADEN',sender:'CEMADEN',evento:a.evento||a.tipo||'Alerta de risco',sev:severity(nivel+' '+(a.evento||'')),inicio:a.ult_atualizacao||a.datahoracriacao||'',fim:a.validade||'',titulo:a.evento||'Alerta CEMADEN',descricao:a.descricao||'',instrucao:a.instrucao||'',area:[municipio,uf].filter(Boolean).join(' / '),municipios:municipio?[municipio]:[],ufs:uf?[uf]:[],poligonos:[],lat:Number(a.latitude)||null,lon:Number(a.longitude)||null,match:false}; });
}
async function rssAlerts(source) {
  const xml=await fetchText(source.url); const items=xml.match(new RegExp('<(?:item|entry)(?:\\s[^>]*)?>[\\s\\S]*?</(?:item|entry)>','gi'))||[];
  return items.map((b,i)=>{const title=one(b,'title'), desc=one(b,'description')||one(b,'summary')||one(b,'content'), link=(b.match(/<link[^>]*href=["']([^"']+)/i)||[])[1]||one(b,'link'); const text=`${title} ${desc}`; const sev=severity(text); const date=one(b,'pubDate')||one(b,'published')||one(b,'updated'); return {id:`${source.id}-${(link||title).slice(0,120)}`,fonte:source.nome,sender:source.nome,evento:title||source.nome,sev,inicio:date,fim:'',titulo:title||source.nome,descricao:desc.slice(0,900),instrucao:'Consulte a publicação oficial para orientações e atualizações.',area:'Santa Catarina',ufs:['SC'],municipios:[],poligonos:[],link:link||source.url};});
}
async function collect(source, fn) { try { const data=await fn(); return {ok:true,source:source.id,total:data.length,data}; } catch(e) { console.error(`Fonte ${source.id}:`,e.message); return {ok:false,source:source.id,total:0,error:String(e.message||e)}; } }
async function main() {
  const results=await Promise.all([
    collect(SOURCES[0],async()=>{const xml=await fetchText(FEED,280000); if(!new RegExp('<\\s*(?:\\w+:)?(?:feed|alert)').test(xml))throw new Error('Resposta não parece CAP/Atom'); return parseCap(xml);}),
    collect(SOURCES[1],cemaden),
    collect(SOURCES[2],()=>rssAlerts(SOURCES[2])),
    collect(SOURCES[3],()=>rssAlerts(SOURCES[3]))
  ]);
  const alerts=results.flatMap(r=>r.data||[]); const seen=new Set(); const unique=alerts.filter(a=>{const k=String(a.id);if(seen.has(k))return false;seen.add(k);return true;});
  const data={fonte:'Agregador de fontes oficiais públicas',atualizado:new Date().toISOString(),total:unique.length,alertas:unique,fontes:results.map(r=>({id:r.source,nome:SOURCES.find(s=>s.id===r.source)?.nome,ok:r.ok,total:r.total,erro:r.error||null,atualizado:new Date().toISOString()})),catalogo:SOURCES.map(({id,nome,url,tipo,cobertura})=>({id,nome,url,tipo,cobertura}))};
  mkdirSync('data',{recursive:true}); writeFileSync('data/idap.json',JSON.stringify(data));
  console.log(`Coleta finalizada: ${unique.length} alertas; ${results.filter(r=>r.ok).length}/${results.length} fontes responderam.`);
  if(!results.some(r=>r.ok))throw new Error('Nenhuma fonte de alertas respondeu.');
}
if(process.argv[1]&&process.argv[1].endsWith('coletar-idap.mjs'))main().catch(e=>{console.error('FALHA:',e.message);process.exit(1);});
