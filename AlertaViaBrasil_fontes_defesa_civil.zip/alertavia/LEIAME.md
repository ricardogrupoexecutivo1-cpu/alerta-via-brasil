# Alerta Via Brasil — publicar e configurar

App PWA: abre por link, instala no celular (Android/iPhone) e no PC, usando a internet do próprio usuário.
**Não abra o index.html direto do computador** (C:/...): o mapa e as funções de servidor só funcionam no link publicado (https).

## Onde publicar
- **Netlify (grátis, permite uso comercial)** — recomendado: https://app.netlify.com/drop → arraste a pasta do projeto. Para as funções de servidor (/api) funcionarem, publique por Git ou pela CLI (`npx netlify deploy --prod`), pois o "drop" só serve arquivos estáticos.
- **Cloudflare Pages** também é grátis, mas exigiria adaptar as funções.
- **Vercel (Hobby)** é grátis, porém os termos do plano Hobby proíbem uso comercial. Como o app cobra assinatura, use o plano pago da Vercel ou outro host.

## Variáveis de ambiente (Settings → Environment variables)
Modo recomendado — confirmação automática do pagamento (Mercado Pago):
- `MP_ACCESS_TOKEN` = token de produção da sua conta Mercado Pago (Seu negócio → Configurações → Credenciais). O dinheiro cai na sua conta Mercado Pago; nenhum CPF aparece em lugar nenhum.
- `PIX_VALOR` = 12 (opcional)

Modo simples — sem confirmação automática:
- `PIX_KEY` = chave Pix (de preferência uma chave aleatória). O botão "Já paguei" libera 30 dias no aparelho.

## Como funciona a trava
- 3 dias de teste grátis (`trialDays` em `index.html`).
- Vencido: o app mostra só a tela de pagamento. No modo Mercado Pago, o app consulta o pagamento a cada 5 s e libera sozinho quando o banco confirma; vale 30 dias, renovável.
- A trava roda no aparelho: quem entende de navegador consegue contorná-la. Para trava real, o servidor teria que emitir um token assinado e exigi-lo nas consultas.

## Conferir os avisos do INMET
Abra `https://SEU-LINK/api/avisos?debug=1` e veja os campos brutos. Se os nomes diferirem, ajuste `normalize` em `lib/core.js`.

## Relatos de alagamento compartilhados (opcional)
```sql
create table reports (id bigint generated always as identity primary key, lat double precision, lon double precision, lvl int check (lvl between 1 and 3), t timestamptz default now());
alter table reports enable row level security;
create policy "ler" on reports for select using (t > now() - interval '6 hours');
create policy "inserir" on reports for insert with check (true);
```
Depois preencha `supabaseUrl` e `supabaseAnonKey` em `CONFIG` no `index.html`.

## Limites
- Open-Meteo gratuito é só para uso não comercial; cobrando assinatura, contrate o plano comercial deles.
- OSRM público e mapas OSM/CARTO são para uso leve.
- Notificações só com o app aberto/recente.


## Agregação de alertas públicos (Defesa Civil)

O coletor `scripts/coletar-idap.mjs` agrega, quando disponíveis, quatro fontes gratuitas: (1) feed CAP da IDAP/Defesa Civil Nacional; (2) painel público do CEMADEN (endpoint não documentado, sujeito a mudanças); (3) RSS oficial da Defesa Civil de Santa Catarina; e (4) RSS oficial de avisos meteorológicos EPAGRI/CIRAM. O endpoint `/api/idap` publica os alertas normalizados, resumo por UF e estado de saúde de cada fonte. A coleta é agendada pelo Netlify a cada 30 minutos.

**Limites importantes:** a IDAP é a principal fonte nacional e recebe alertas cadastrados por órgãos estaduais e municipais, mas não existe uma API pública gratuita e padronizada para cada uma das 27 unidades federativas. O feed CEMADEN `wsAlertas2` é público, porém não documentado e pode mudar. A Defesa Civil do Paraná oferece painel oficial, mas não foi identificado neste projeto um endpoint público estável/documentado para integração automática. A API hidrometeorológica do RS fornece leituras de estações/rios, não é um feed de alertas da Defesa Civil e deve ser integrada como camada de monitoramento separada, não como alerta oficial.

As fontes são consultadas no servidor, com timeout e status individual. Uma fonte indisponível não deve ser interpretada como ausência de risco. A interface deve continuar exibindo a origem e o horário da última coleta.
