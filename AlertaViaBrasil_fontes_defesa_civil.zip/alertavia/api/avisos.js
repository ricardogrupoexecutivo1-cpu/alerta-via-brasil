import { avisos } from '../lib/core.js';
export default async function handler(req, res) {
  const r = await avisos(req.query && req.query.debug);
  if (r.cache) res.setHeader('Cache-Control', `s-maxage=${r.cache}, stale-while-revalidate=600`);
  res.status(r.status).json(r.body);
}
