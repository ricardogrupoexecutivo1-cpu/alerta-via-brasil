import { pixCriar } from '../lib/core.js';
export default async function handler(req, res) {
  const email = (req.query && req.query.email) || '';
  const r = await pixCriar(String(email));
  res.setHeader('Cache-Control', 'no-store');
  res.status(r.status).json(r.body);
}
