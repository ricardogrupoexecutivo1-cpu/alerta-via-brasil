import { pixStatus } from '../lib/core.js';
export default async function handler(req, res) {
  const r = await pixStatus(req.query && req.query.id);
  res.setHeader('Cache-Control', 'no-store');
  res.status(r.status).json(r.body);
}
