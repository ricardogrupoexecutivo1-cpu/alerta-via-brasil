import { getStore } from '@netlify/blobs';
import { parseCap } from '../../scripts/coletar-idap.mjs';
const FEED = 'https://idapfile.mdr.gov.br/idap/api/rss/cap';
// Sem segredo: o próprio limite de frequência (1 coleta a cada 20 min) impede abuso/custo.
export default async () => {
  const store = getStore('idap');
  const ult = await store.get('tentativa', { type: 'json' }).catch(() => null);
  if (ult && Date.now() - ult.t < 20 * 60 * 1000) { console.log('coleta recente, ignorada'); return; }
  await store.setJSON('tentativa', { t: Date.now() });
  const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 600000);
  try {
    const r = await fetch(FEED, { headers: { 'User-Agent': 'AlertaViaBrasil-Coletor/1.0', Accept: 'application/atom+xml, application/xml, text/xml, */*' }, signal: ctl.signal });
    if (!r.ok) throw new Error('IDAP HTTP ' + r.status);
    const xml = await r.text(); clearTimeout(to);
    if (!/<\s*(?:\w+:)?(?:feed|alert)/.test(xml)) throw new Error('Resposta não parece CAP');
    const alertas = parseCap(xml);
    await store.setJSON('atual', { fonte: 'Defesa Civil Nacional (IDAP/CAP)', atualizado: new Date().toISOString(), total: alertas.length, alertas });
    console.log('OK', alertas.length, 'alertas;', (xml.length / 1e6).toFixed(1), 'MB');
  } catch (e) { console.error('FALHA na coleta:', e.message); }
};
export const config = { background: true, path: '/api/idap-coletar', method: 'POST' };
