import { pixStatus } from '../../lib/core.js';
export default async (req) => {
  const r = await pixStatus(new URL(req.url).searchParams.get('id'));
  return new Response(JSON.stringify(r.body), { status: r.status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
};
export const config = { path: '/api/pix-status' };
