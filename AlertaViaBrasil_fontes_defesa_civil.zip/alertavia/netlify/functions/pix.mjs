import { pixCriar } from '../../lib/core.js';
export default async (req) => {
  const r = await pixCriar(new URL(req.url).searchParams.get('email') || '');
  return new Response(JSON.stringify(r.body), { status: r.status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
};
export const config = { path: '/api/pix' };
