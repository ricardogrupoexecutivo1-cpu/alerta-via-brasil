import { avisos } from '../../lib/core.js';
export default async (req) => {
  const r = await avisos(new URL(req.url).searchParams.get('debug'));
  return new Response(JSON.stringify(r.body), { status: r.status, headers: { 'content-type': 'application/json', 'cache-control': r.cache ? `public, max-age=0, s-maxage=${r.cache}` : 'no-store' } });
};
export const config = { path: '/api/avisos' };
