// Agendada (cron em UTC): a cada 30 min dispara a coleta pesada em função de fundo (limite de 15 min).
export default async (req, context) => {
  const base = (context && context.site && context.site.url) || Netlify.env.get('URL');
  const r = await fetch(`${base}/api/idap-coletar`, { method: 'POST' });
  console.log('disparo da coleta:', r.status);
};
export const config = { schedule: '*/30 * * * *' };
