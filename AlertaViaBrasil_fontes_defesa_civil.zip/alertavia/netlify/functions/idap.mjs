import { getStore } from '@netlify/blobs';
const J = (o, cache) => new Response(JSON.stringify(o), { headers: { 'content-type': 'application/json', 'cache-control': cache || 'no-store' } });
function inRing(lat, lon, r) { let ins = false; for (let i = 0, j = r.length - 1; i < r.length; j = i++) { const [yi, xi] = r[i], [yj, xj] = r[j]; if ((xi > lon) !== (xj > lon) && lat < (yj - yi) * (lon - xi) / (xj - xi) + yi) ins = !ins; } return ins; }
const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
export default async (req) => {
  try {
    const d = await getStore('idap').get('atual', { type: 'json' });
    if (!d) return J({ vazio: true, alertas: [], resumo: {}, fontes: [], catalogo: [] });
    const u = new URL(req.url); const lat = parseFloat(u.searchParams.get('lat')); const lon = parseFloat(u.searchParams.get('lon')); const nome = norm(u.searchParams.get('nome'));
    // resumo por UF (pequeno) para a lista do Brasil
    const resumo = {};
    for (const a of d.alertas) for (const uf of (a.ufs || [])) { const r = (resumo[uf] = resumo[uf] || { n: 0, sev: 1, eventos: [] }); r.n++; r.sev = Math.max(r.sev, a.sev || 1); if (a.evento && !r.eventos.includes(a.evento) && r.eventos.length < 6) r.eventos.push(a.evento); }
    // somente os alertas que atingem a localização do usuário (sem polígonos: resposta leve)
    const alertas = [];
    if (Number.isFinite(lat) && Number.isFinite(lon)) {
      for (const a of d.alertas) {
        const hit = (a.poligonos || []).some((r) => inRing(lat, lon, r)) || (nome.length > 3 && norm(a.area).includes(nome));
        if (hit) { const { poligonos, ibge, ...rest } = a; alertas.push({ ...rest, match: true }); }
      }
    }
    return J({ fonte: d.fonte, atualizado: d.atualizado, total: d.total, resumo, alertas, fontes: d.fontes || [], catalogo: d.catalogo || [] }, 'public, max-age=60, s-maxage=120');
  } catch (e) { return J({ erro: 'Falha ao ler alertas.' }); }
};
export const config = { path: '/api/idap' };
